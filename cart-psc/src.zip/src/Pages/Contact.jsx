
import React from "react";

const Contact = () => {
    return (
        <h2>Contact</h2>

    )
}

export default Contact

